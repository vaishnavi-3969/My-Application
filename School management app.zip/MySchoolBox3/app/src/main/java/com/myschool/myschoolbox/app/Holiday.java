package com.myschool.myschoolbox.app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Holiday extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_holiday);
    }
}