package com.myschool.myschoolbox.app.Model;

public class Usermodel {
    String admission, rollnumber, sestion, fathername, mothername, gender, dob, fatherno, motherno, bloodgroup,
            email, mobilenumber, classname, village, post, ps, pin, dis, state, contry, tutionfee, annualfee,
            monthlyfee, dues, totalfee, month, year, present, holiday, absent, leave, halfday, totalattendance,
            clname, one, onetotal, oneget, two, twototal,
            twoget, three, threetotal, threeget, four, fourtotale, fourget, fife, fifetotal, fifeget, six, sixtotal, sixget, seven, seventotal, sevenget, eight, eighttotal, eightget, nine, ninetotal, nineget, ten, tentotal, tenget, pass;


    public Usermodel(String ad, String roll, String sec, String fatn, String motn, String gen, String date, String fatno, String motno, String blod, String eml, String mnumber, String cls, String vill, String pst, String policestation, String pn, String ds, String sta, String con, String tut, String anu, String monfee, String due, String tfee, String adm, String mon, String yr, String pre, String hol, String abs, String lea, String hal, String aatatandance, String clme, String o, String og, String t, String ttwt, String ttgt, String thr, String thto, String thget, String fr, String fif, String fift, String fifg, String sx, String sxot, String sxog, String sev, String sevt, String eig, String eigt, String s, String nin, String nint, String ning, String tn, String tnt, String tng, String pss, String psw) {
    }

    public Usermodel(String admission, String rollnumber, String sestion, String fathername, String mothername, String gender, String dob, String fatherno, String motherno, String bloodgroup, String email, String mobilenumber, String classname, String village, String post, String ps, String pin, String dis, String state, String contry, String tutionfee, String annualfee, String monthlyfee, String dues, String totalfee, String month, String year, String present, String holiday, String absent, String leave, String halfday, String totalattendance, String clname, String one, String onetotal, String oneget, String two, String twototal, String twoget, String three, String threetotal, String threeget, String four, String fourtotale, String fourget, String fife, String fifetotal, String fifeget, String six, String sixtotal, String sixget, String seven, String seventotal, String sevenget, String eight, String eighttotal, String eightget, String nine, String ninetotal, String nineget, String ten, String tentotal, String tenget, String pass) {
        this.admission = admission;
        this.rollnumber = rollnumber;
        this.sestion = sestion;
        this.fathername = fathername;
        this.mothername = mothername;
        this.gender = gender;
        this.dob = dob;
        this.fatherno = fatherno;
        this.motherno = motherno;
        this.bloodgroup = bloodgroup;
        this.email = email;
        this.mobilenumber = mobilenumber;
        this.classname = classname;
        this.village = village;
        this.post = post;
        this.ps = ps;
        this.pin = pin;
        this.dis = dis;
        this.state = state;
        this.contry = contry;
        this.tutionfee = tutionfee;
        this.annualfee = annualfee;
        this.monthlyfee = monthlyfee;
        this.dues = dues;
        this.totalfee = totalfee;
        this.month = month;
        this.year = year;
        this.present = present;
        this.holiday = holiday;
        this.absent = absent;
        this.leave = leave;
        this.halfday = halfday;
        this.totalattendance = totalattendance;
        this.clname = clname;
        this.one = one;
        this.onetotal = onetotal;
        this.oneget = oneget;
        this.two = two;
        this.twototal = twototal;
        this.twoget = twoget;
        this.three = three;
        this.threetotal = threetotal;
        this.threeget = threeget;
        this.four = four;
        this.fourtotale = fourtotale;
        this.fourget = fourget;
        this.fife = fife;
        this.fifetotal = fifetotal;
        this.fifeget = fifeget;
        this.six = six;
        this.sixtotal = sixtotal;
        this.sixget = sixget;
        this.seven = seven;
        this.seventotal = seventotal;
        this.sevenget = sevenget;
        this.eight = eight;
        this.eighttotal = eighttotal;
        this.eightget = eightget;
        this.nine = nine;
        this.ninetotal = ninetotal;
        this.nineget = nineget;
        this.ten = ten;
        this.tentotal = tentotal;
        this.tenget = tenget;
        this.pass = pass;
    }

    public String getAdmission() {
        return admission;
    }

    public void setAdmission(String admission) {
        this.admission = admission;
    }

    public String getRollnumber() {
        return rollnumber;
    }

    public void setRollnumber(String rollnumber) {
        this.rollnumber = rollnumber;
    }

    public String getSestion() {
        return sestion;
    }

    public void setSestion(String sestion) {
        this.sestion = sestion;
    }

    public String getFathername() {
        return fathername;
    }

    public void setFathername(String fathername) {
        this.fathername = fathername;
    }

    public String getMothername() {
        return mothername;
    }

    public void setMothername(String mothername) {
        this.mothername = mothername;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getFatherno() {
        return fatherno;
    }

    public void setFatherno(String fatherno) {
        this.fatherno = fatherno;
    }

    public String getMotherno() {
        return motherno;
    }

    public void setMotherno(String motherno) {
        this.motherno = motherno;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobilenumber() {
        return mobilenumber;
    }

    public void setMobilenumber(String mobilenumber) {
        this.mobilenumber = mobilenumber;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getPs() {
        return ps;
    }

    public void setPs(String ps) {
        this.ps = ps;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getDis() {
        return dis;
    }

    public void setDis(String dis) {
        this.dis = dis;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getContry() {
        return contry;
    }

    public void setContry(String contry) {
        this.contry = contry;
    }

    public String getTutionfee() {
        return tutionfee;
    }

    public void setTutionfee(String tutionfee) {
        this.tutionfee = tutionfee;
    }

    public String getAnnualfee() {
        return annualfee;
    }

    public void setAnnualfee(String annualfee) {
        this.annualfee = annualfee;
    }

    public String getMonthlyfee() {
        return monthlyfee;
    }

    public void setMonthlyfee(String monthlyfee) {
        this.monthlyfee = monthlyfee;
    }

    public String getDues() {
        return dues;
    }

    public void setDues(String dues) {
        this.dues = dues;
    }

    public String getTotalfee() {
        return totalfee;
    }

    public void setTotalfee(String totalfee) {
        this.totalfee = totalfee;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getPresent() {
        return present;
    }

    public void setPresent(String present) {
        this.present = present;
    }

    public String getHoliday() {
        return holiday;
    }

    public void setHoliday(String holiday) {
        this.holiday = holiday;
    }

    public String getAbsent() {
        return absent;
    }

    public void setAbsent(String absent) {
        this.absent = absent;
    }

    public String getLeave() {
        return leave;
    }

    public void setLeave(String leave) {
        this.leave = leave;
    }

    public String getHalfday() {
        return halfday;
    }

    public void setHalfday(String halfday) {
        this.halfday = halfday;
    }

    public String getTotalattendance() {
        return totalattendance;
    }

    public void setTotalattendance(String totalattendance) {
        this.totalattendance = totalattendance;
    }

    public String getClname() {
        return clname;
    }

    public void setClname(String clname) {
        this.clname = clname;
    }

    public String getOne() {
        return one;
    }

    public void setOne(String one) {
        this.one = one;
    }

    public String getOnetotal() {
        return onetotal;
    }

    public void setOnetotal(String onetotal) {
        this.onetotal = onetotal;
    }

    public String getOneget() {
        return oneget;
    }

    public void setOneget(String oneget) {
        this.oneget = oneget;
    }

    public String getTwo() {
        return two;
    }

    public void setTwo(String two) {
        this.two = two;
    }

    public String getTwototal() {
        return twototal;
    }

    public void setTwototal(String twototal) {
        this.twototal = twototal;
    }

    public String getTwoget() {
        return twoget;
    }

    public void setTwoget(String twoget) {
        this.twoget = twoget;
    }

    public String getThree() {
        return three;
    }

    public void setThree(String three) {
        this.three = three;
    }

    public String getThreetotal() {
        return threetotal;
    }

    public void setThreetotal(String threetotal) {
        this.threetotal = threetotal;
    }

    public String getThreeget() {
        return threeget;
    }

    public void setThreeget(String threeget) {
        this.threeget = threeget;
    }

    public String getFour() {
        return four;
    }

    public void setFour(String four) {
        this.four = four;
    }

    public String getFourtotale() {
        return fourtotale;
    }

    public void setFourtotale(String fourtotale) {
        this.fourtotale = fourtotale;
    }

    public String getFourget() {
        return fourget;
    }

    public void setFourget(String fourget) {
        this.fourget = fourget;
    }

    public String getFife() {
        return fife;
    }

    public void setFife(String fife) {
        this.fife = fife;
    }

    public String getFifetotal() {
        return fifetotal;
    }

    public void setFifetotal(String fifetotal) {
        this.fifetotal = fifetotal;
    }

    public String getFifeget() {
        return fifeget;
    }

    public void setFifeget(String fifeget) {
        this.fifeget = fifeget;
    }

    public String getSix() {
        return six;
    }

    public void setSix(String six) {
        this.six = six;
    }

    public String getSixtotal() {
        return sixtotal;
    }

    public void setSixtotal(String sixtotal) {
        this.sixtotal = sixtotal;
    }

    public String getSixget() {
        return sixget;
    }

    public void setSixget(String sixget) {
        this.sixget = sixget;
    }

    public String getSeven() {
        return seven;
    }

    public void setSeven(String seven) {
        this.seven = seven;
    }

    public String getSeventotal() {
        return seventotal;
    }

    public void setSeventotal(String seventotal) {
        this.seventotal = seventotal;
    }

    public String getSevenget() {
        return sevenget;
    }

    public void setSevenget(String sevenget) {
        this.sevenget = sevenget;
    }

    public String getEight() {
        return eight;
    }

    public void setEight(String eight) {
        this.eight = eight;
    }

    public String getEighttotal() {
        return eighttotal;
    }

    public void setEighttotal(String eighttotal) {
        this.eighttotal = eighttotal;
    }

    public String getEightget() {
        return eightget;
    }

    public void setEightget(String eightget) {
        this.eightget = eightget;
    }

    public String getNine() {
        return nine;
    }

    public void setNine(String nine) {
        this.nine = nine;
    }

    public String getNinetotal() {
        return ninetotal;
    }

    public void setNinetotal(String ninetotal) {
        this.ninetotal = ninetotal;
    }

    public String getNineget() {
        return nineget;
    }

    public void setNineget(String nineget) {
        this.nineget = nineget;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getTentotal() {
        return tentotal;
    }

    public void setTentotal(String tentotal) {
        this.tentotal = tentotal;
    }

    public String getTenget() {
        return tenget;
    }

    public void setTenget(String tenget) {
        this.tenget = tenget;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public static class Homeworkmodel {
        String subject, date, heading, note, classname, url;

        public Homeworkmodel() {
        }

        public Homeworkmodel(String subject, String date, String heading, String note, String classname, String url) {
            this.subject = subject;
            this.date = date;
            this.heading = heading;
            this.note = note;
            this.classname = classname;
            this.url = url;
        }

        public String getSubject() {
            return subject;
        }

        public void setSubject(String subject) {
            this.subject = subject;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getHeading() {
            return heading;
        }

        public void setHeading(String heading) {
            this.heading = heading;
        }

        public String getNote() {
            return note;
        }

        public void setNote(String note) {
            this.note = note;
        }

        public String getClassname() {
            return classname;
        }

        public void setClassname(String classname) {
            this.classname = classname;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }
}
