package com.myschool.myschoolbox.app.Model;

public class HomeworkModel {
}
