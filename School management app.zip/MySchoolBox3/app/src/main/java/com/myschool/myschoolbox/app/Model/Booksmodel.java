package com.myschool.myschoolbox.app.Model;

public class Booksmodel {
    String url;

    public Booksmodel() {
    }

    public Booksmodel(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
